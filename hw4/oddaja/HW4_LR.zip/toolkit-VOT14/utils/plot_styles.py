
def load_plot_styles():
    styles = [{'color': 'r', 'marker': 'o'}, \
        {'color': 'g', 'marker': '*'}, \
        {'color': 'b', 'marker': 'P'}, \
        {'color': 'm', 'marker': 'X'}, \
        {'color': 'sandybrown', 'marker': 'D'}]
    return styles
